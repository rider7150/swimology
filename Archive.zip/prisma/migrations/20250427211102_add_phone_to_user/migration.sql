-- AlterTable
ALTER TABLE "User" ADD COLUMN     "phoneNumber" TEXT;
