-- AlterTable
ALTER TABLE "ClassLevel" ADD COLUMN     "order" INTEGER NOT NULL DEFAULT 0;
