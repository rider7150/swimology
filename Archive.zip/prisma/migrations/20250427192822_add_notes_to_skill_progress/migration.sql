-- AlterTable
ALTER TABLE "SkillProgress" ADD COLUMN     "notes" TEXT;
