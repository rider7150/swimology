-- AlterTable
ALTER TABLE "Enrollment" ADD COLUMN     "readyForNextLevel" BOOLEAN NOT NULL DEFAULT false;
