// src/app/api/parents/[parentId]/route.ts
export const runtime = 'nodejs';    // ← Add this!

import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(
  req: NextRequest,
  { params }: { params: { parentId: string } }
) {
  const { parentId } = params;

  const parent = await prisma.parent.findUnique({
    where: { id: parentId },
    include: { children: true },
  });

  if (!parent) {
    return NextResponse.json({ error: "Parent not found" }, { status: 404 });
  }

  return NextResponse.json(parent);
}